<?php
//  ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    				//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              //
//                   										//
//                  Authors :									//
//						- solo (www.wolfpackclan.com)         	//
//                  Moved v1.1								//
//  ------------------------------------------------------------------------ 	//

/////////////////////////////////////////////
/// Replace here with your module name 	///
/// 	  			     			///
    	$MODULE = "newbb";
/// 	  			     			///
/// ex. = wfsection -> smartsection	     	///
/////////////////////////////////////////////





////////////////////////////////////////////////////////////////////////////////////////

define("_MI_".$MODULE."_PAGE",		"Page de redirection");
define("_MI_".$MODULE."_PAGE_DSC",		"Afficher une page de redirection.");

define("_MI_".$MODULE."_TEXTINDEX",		"Texte");
define("_MI_".$MODULE."_TEXTINDEXDSC",	"Texte de la page de redirection");
define("_MI_MOVED_WELCOME",			"
La page que vous souhaitez afficher n'existe plus. Vous allez �tre redirig� dans un instant.");

define("_MI_".$MODULE."_INDEX_BANNER",	"Logo");
define("_MI_".$MODULE."_INDEXDSC_BANNER",	"Afficher une banni�re sur la page de redirection. Laisser vide pour ne rien afficher.");

define("_MI_".$MODULE."_INDEX",		"Redirection");
define("_MI_".$MODULE."_INDEX_DSC",		"Indiquez l'url de redirection<br />
- URL absolue ou relative. <br />
- Laisser vierge pour la page d'accueil.");

define("_MI_".$MODULE."_INDEX_TIMER",	"Temps de redirection");
define("_MI_".$MODULE."_INDEXDSC_TIMER",	"Dur�e en seconde d'affichage de la page de redirection.");

define("_MI_".$MODULE."_TRACKER",		"Traquer redirection");
define("_MI_".$MODULE."_TRACKER_DSC",	"Activer la surveillance des pages de redirection.");

define("_MI_".$MODULE."_TRACKER_CLEAN",		"Nettoyer les entr�es");
define("_MI_".$MODULE."_TRACKER_CLEAN_DSC",	"Supprimer automatiquement les entr�e les plus anciennes. D�fini en jours. 0 pour ne rien supprimer.");

define("_MI_".$MODULE."_WARN",		"Avertissement par mail");
define("_MI_".$MODULE."_WARN_DSC",		"Avertis par mail lorsqu'une nouvelle entr�e est d�tect�e.");

define("_MI_MOVED_WARN_NONE",		"Jamais");
define("_MI_MOVED_WARN_MYSITE",	"Seulement en provenance de ce site.");
define("_MI_MOVED_WARN_ALL",		"Toutes les entr�es (interne et externes au site).");
?>

