<?php
//  ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    				//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              //
//                   										//
//                  Authors :									//
//						- solo (www.wolfpackclan.com)         	//
//                  Moved v1.1								//
//  ------------------------------------------------------------------------ 	//

/////////////////////////////////////////////
/// Indiquer ici le nom de votre module 	///
/// 	  			     			///
    		$MODULE = "newbb";
/// 	  			     			///
/// ex. = wfsection -> smartsection	     	///
/////////////////////////////////////////////





////////////////////////////////////////////////////////////////////////////////////////

define("_MI_".$MODULE."_PAGE",		"Redirection page");
define("_MI_".$MODULE."_PAGE_DSC",		"Display a redirection page when redirected.");

define("_MI_".$MODULE."_TEXTINDEX",		"Text");
define("_MI_".$MODULE."_TEXTINDEXDSC",	"Redirection's page text");
define("_MI_".$MODULE."_WELCOME",			"
The page you want to display is not available anymore. You will be redirected in moment.");

define("_MI_".$MODULE."_INDEX_BANNER",	"Logo");
define("_MI_".$MODULE."_INDEXDSC_BANNER",	"Display a logo on the redirection page. Leave empty to display nothing.");

define("_MI_".$MODULE."_INDEX",		"Redirection");
define("_MI_".$MODULE."_INDEX_DSC",		"Replace the missing page or module by the redirection<br />
- Display an absolute or relative url. <br />
- Leave blank for default index.");

define("_MI_".$MODULE."_INDEX_TIMER",	"Redirection time");
define("_MI_".$MODULE."_INDEXDSC_TIMER",	"Time in seconds to display the redirection page.");

define("_MI_".$MODULE."_TRACKER",		"Activate referer's tracker ?");
define("_MI_".$MODULE."_TRACKER_DSC",	"Activate backlinks to redirected pages.");

define("_MI_".$MODULE."_TRACKER_CLEAN",		"Entry clean up");
define("_MI_".$MODULE."_TRACKER_CLEAN_DSC",	"Automatically clean up oldest entries. Set in days. 0 for no clean up.");

define("_MI_".$MODULE."_WARN",		"Warn for new entry");
define("_MI_".$MODULE."_WARN_DSC",		"Send a mail for each new entry.");
define("_MI_".$MODULE."_WARN_NONE",		"Never");
define("_MI_".$MODULE."_WARN_MYSITE",	"Only from current site.");
define("_MI_".$MODULE."_WARN_ALL",		"All entries (interne and externe backlink).");
?>

