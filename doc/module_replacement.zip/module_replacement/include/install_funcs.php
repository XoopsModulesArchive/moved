<?php
//  ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    				//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              //
//                   										//
//                  Authors :									//
//						- solo (www.wolfpackclan.com)         	//
//                  Moved v1.0								//
//  ------------------------------------------------------------------------ 	//

function xoops_module_install_module_replacement(&$module)
{
    $groupperm_handler =& xoops_gethandler('groupperm');
    return $groupperm_handler->addRight('module_read', $module->getVar('mid'), XOOPS_GROUP_ANONYMOUS);
}
?>
