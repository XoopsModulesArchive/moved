//    ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    			//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              	//
//                   								//
//                  Authors :							//
//				- solo (www.wolfpackclan.com)   		//
//                  Moved v1.0							//
//    ------------------------------------------------------------------------ 	//

Description

This is a missing module page redirection module, which allows you to redirect bots or user from a missing module pages, to another place of your choice. 

1) Installation
The purpose of this module is to replace a missing module. Follow the next 6 steps to proceed to the missing module replacement;

1. Unzip the Moved module on your hardrive.

2. Rename the 'module_replacement' directory with the replaced module name (ie. : module_replacement -> section)

	3a. Edit the 'xoops_version.php' file, and replace the followin line : 
   		$module = "module_replacement"; 
   		with the replaced module name : (ie : $module = "section";)

	3b.Edit the 'language/DEFAULT_LANGUAGE/modinfo.php' file, and replace the followin line : 
   		$module = "module_replacement"; 
   		with the replaced module name : (ie : $module = "section";)

	3c.Edit the 'include/install_funcs.php' file, and replace the followin line : 
   		xoops_module_install_module_replacement(&$module) { 
   		with the replaced module name : (ie : xoops_module_install_section(&$module) {)


d. Upload the so created directory on the server 'modules' directory of your Xoops site.

e. Install throught the module admin system.

f. Edit the module preferences, and indicate the replacement module url. 
   (ie : modules/smartsection/)

That's it.


2) Module Preferences
Click on the module logo's preferences link in admin area.

1.a. Redirection

Replace the replaced index page by another page.
- Displaying an absolute or relative url (can be outside your website). 
- Leave blank for default homepage (default).

1.b. Index Logo

Display a logoon your redirection page. Enter the picture url here. Leave empty to display none. 

1.c. Redirection text

Place here your redirection message. 

1.d. Redirection timer
Define how many second the redirection page is displayed in seconds.


3) Module adaptation
Default redirection pages are following :
- index.php
- article.php
- category.php
- client.php
- content.php
- item.php
- join.php
- page.php
- print.php
- rate.php
- submit.php

Check in your replaced module (module root files) wether those files cover all the existing file. If some are missing, just copy the index.php file from the moved module and rename it alike the removed module missing file.


4) More than one module...

It is possible to clone the 'module_replacement' module and use it for more than one missing module. Just respect the installation process as explained above.


Happy Xoopsing

Solo
www.wolfpackclan.com/wolfactory
