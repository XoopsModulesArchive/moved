<?php
//  ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    				//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              //
//                   										//
//                  Authors :									//
//						- solo (www.wolfpackclan.com)         	//
//                  Moved v1.1								//
//  ------------------------------------------------------------------------ 	//

define("_MOVED_MAIL_OBJECT",	"Probl�me de lien : ");
define("_MOVED_MAIL_CORE",	"Ce r�f�rant pointe sur la page");
?>

