<?php
//  ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    				//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              //
//                   										//
//                  Authors :									//
//						- solo (www.wolfpackclan.com)         	//
//                  Moved v1.0								//
//  ------------------------------------------------------------------------ 	//

// General settings
include_once("header.php");
include_once(XOOPS_ROOT_PATH."/header.php");
$myts =& MyTextSanitizer::getInstance();

if (isset($_GET ["storyid"])) $storyid= intval($_GET ["storyid"]);
if (isset($_POST ["storyid"])) $storyid= intval($_POST ["storyid"]);

// Module Banner
if ($xoopsModuleConfig['moved_banner']) {
 $banner = '<img src="'.$xoopsModuleConfig['moved_banner'].'" alt="'.$xoopsModule -> getVar('name').'">'; 
 } else {
 $banner = '';}


//Rediriger l'index vers une url sp�cifique
		if (	$xoopsModuleConfig['moved_index'] AND 
 			!eregi("/".$xoopsModule -> getVar('dirname'), $xoopsModuleConfig['moved_index']) ) {

			if (	eregi("http://", $xoopsModuleConfig['moved_index']) OR 
				eregi("https://", $xoopsModuleConfig['moved_index']) )
 				{
				$redirect = $xoopsModuleConfig['moved_index'].'/article.php?storyid='.$storyid;
			 	} else {
				$redirect = XOOPS_URL.'/'.$xoopsModuleConfig['moved_index'].'/article.php?storyid='.$storyid;
				}
		} else {
			$redirect = '../../index.php';
		}

echo'
<div align="center">
'.$banner.'</div>';

redirect_header( $redirect, $xoopsModuleConfig['moved_timer'], $xoopsModuleConfig['moved_text']);
exit();

include_once(XOOPS_ROOT_PATH."/footer.php");
?>
