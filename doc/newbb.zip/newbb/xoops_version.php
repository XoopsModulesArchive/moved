<?php
//  ------------------------------------------------------------------------ 	//
//                XOOPS - PHP Content Management System    				//
//                    Copyright (c) 2004 XOOPS.org                       	//
//                       <http://www.xoops.org/>                              //
//                   										//
//                  Authors :									//
//						- solo (www.wolfpackclan.com)         	//
//                  Moved v1.0								//
//  ------------------------------------------------------------------------ 	//

/////////////////////////////////////////////
/// Indiquer ici le nom de votre module 	///
/// Type here your replaced module name	///
/// 	  			     			///
    		$module = "newbb";
/// 	  			     			///
/// ex. = wfsection -> smartsection	     	///
/////////////////////////////////////////////

$modversion['name'] = '[MOVED] '.$module;
$modversion['version'] = 1.0;
$modversion['description'] = '';
$modversion['credits'] = "Solo (www.wolfpackclan.com)";
$modversion['author'] = "Solo";
$modversion['help'] = "";
$modversion['license'] = "GPL see LICENSE";
$modversion['official'] = 0;
$modversion['image'] = "images/moved_slogo.png";
$modversion['dirname'] = $module;


//Admin
// Admin things
$modversion['hasAdmin'] = 1;
$modversion['adminindex'] = "../moved/admin/index.php";

//Main
$modversion['hasMain'] = 0;

// On Install
$modversion['onInstall'] = 'include/install_funcs.php';

// Options
$modversion['config'][1]['name'] = 'moved_index';
$modversion['config'][1]['title'] = '_MI_'.$module.'_INDEX';
$modversion['config'][1]['description'] = '_MI_'.$module.'_INDEX_DSC';
$modversion['config'][1]['formtype'] = 'textbox';
$modversion['config'][1]['valuetype'] = 'text';
$modversion['config'][1]['default'] = '';

$modversion['config'][2]['name'] = 'page';
$modversion['config'][2]['title'] = '_MI_'.$module.'_PAGE';
$modversion['config'][2]['description'] = '_MI_'.$module.'_PAGE_DSC';
$modversion['config'][2]['formtype'] = 'yesno';
$modversion['config'][2]['valuetype'] = 'int';
$modversion['config'][2]['default'] = 1;

$modversion['config'][3]['name'] = 'moved_banner';
$modversion['config'][3]['title'] = '_MI_'.$module.'_INDEX_BANNER';
$modversion['config'][3]['description'] = '_MI_'.$module.'_INDEXDSC_BANNER';
$modversion['config'][3]['formtype'] = 'textbox';
$modversion['config'][3]['valuetype'] = 'text';
$modversion['config'][3]['default'] = 'images/banner.gif';

$modversion['config'][4]['name'] = 'moved_text';
$modversion['config'][4]['title'] = '_MI_'.$module.'_TEXTINDEX';
$modversion['config'][4]['description'] = '_MI_'.$module.'_TEXTINDEXDSC';
$modversion['config'][4]['formtype'] = 'textarea';
$modversion['config'][4]['valuetype'] = 'text';
$modversion['config'][4]['default'] = '';

$modversion['config'][5]['name'] = 'moved_timer';
$modversion['config'][5]['title'] = '_MI_'.$module.'_INDEX_TIMER';
$modversion['config'][5]['description'] = '_MI_'.$module.'_INDEXDSC_TIMER';
$modversion['config'][5]['formtype'] = 'textbox';
$modversion['config'][5]['valuetype'] = 'text';
$modversion['config'][5]['default'] = 3;

$modversion['config'][6]['name'] = 'tracker';
$modversion['config'][6]['title'] = '_MI_'.$module.'_TRACKER';
$modversion['config'][6]['description'] = '_MI_'.$module.'_TRACKER_DSC';
$modversion['config'][6]['formtype'] = 'yesno';
$modversion['config'][6]['valuetype'] = 'int';
$modversion['config'][6]['default'] = 1;

$modversion['config'][7]['name'] = 'tracker_clean';
$modversion['config'][7]['title'] = '_MI_'.$module.'_TRACKER_CLEAN';
$modversion['config'][7]['description'] = '_MI_'.$module.'_TRACKER_CLEAN_DSC';
$modversion['config'][7]['formtype'] = 'textbox';
$modversion['config'][7]['valuetype'] = 'text';
$modversion['config'][7]['default'] = 7;

$modversion['config'][8]['name'] = 'warning';
$modversion['config'][8]['title'] = '_MI_'.$module.'_WARN';
$modversion['config'][8]['description'] = '_MI_'.$module.'_WARN_DSC';
$modversion['config'][8]['formtype'] = 'select';
$modversion['config'][8]['valuetype'] = 'text';
$modversion['config'][8]['default'] = 'mail';
$modversion['config'][8]['options'] = array ( 
								'_MI_MOVED_WARN_NONE' => 	'none', 
								'_MI_MOVED_WARN_MYSITE' => 	'mysite', 
								'_MI_MOVED_WARN_ALL' => 	'all'
							);
?>